﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Conversor de kilómetros a metros, yardas y varas");

        double kilometros;  //variable

        do
        { //comparacion de valores 
            Console.Write("Ingrese la cantidad en kilómetros: ");
        } while (!double.TryParse(Console.ReadLine(), out kilometros) || kilometros < 0);

        // variables

        double metros = kilometros * 1000;         // 1 kilómetro = 1000 metros
        double yardas = metros / 1.09361;          // 1 metro = 1.09361 yardas
        double varas = metros / 1.1963;            // 1 metro = 1.1963 varas
        //lectura de resultados 
        Console.WriteLine($"\nResultados para {kilometros}  kilómetros:");
        Console.WriteLine($"En metros: {metros}  metros");
        Console.WriteLine($"En yardas: {yardas}  yardas");
        Console.WriteLine($"En varas: {varas}  varas");

    }
}