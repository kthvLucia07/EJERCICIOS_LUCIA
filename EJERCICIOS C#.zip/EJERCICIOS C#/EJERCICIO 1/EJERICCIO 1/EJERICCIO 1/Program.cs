﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Bienvenido al programa de cálculo de promedio final de ventas");

        Console.Write("Ingrese su nombre: ");
        string nombre = Console.ReadLine();

        Console.Write("Ingrese su apellido: ");
        string apellido = Console.ReadLine();

        const int diasDelMes = 30;
        double totalVentas = 0;


        for (int dia = 1; dia <= diasDelMes; dia++)
        {
            double ventasDia;

            do
            {
                Console.Write($"Ingrese las ventas del día {dia}: ");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Error: Debe ingresar un valor para las ventas del día.");
                    continue;
                }

                if (!double.TryParse(input, out ventasDia))
                {
                    Console.WriteLine("Error: Ingrese un valor numérico válido para las ventas del día.");
                    continue;
                }

                if (ventasDia < 0)
                {
                    Console.WriteLine("Error: El valor de las ventas no puede ser negativo.");
                }

            } while (ventasDia <= 0);

            totalVentas += ventasDia;
        }

        double promedioFinalVentas = totalVentas / diasDelMes;

        Console.WriteLine($"\nResumen de ventas para {nombre} {apellido}:");
        Console.WriteLine($"Días del mes alcanzados: {diasDelMes}");
        Console.WriteLine($"Total de ventas: {totalVentas}");
        Console.WriteLine($"Promedio final de ventas: {promedioFinalVentas:F2}"); // Limitar decimales a 2
    }
}