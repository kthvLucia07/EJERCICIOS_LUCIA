﻿//el sueldo base de un empleado y que determine los descuentos y sueldo neto.Minimo 3300, renta 10% , afp 7%
//seguro social 5%                                                                                           
using System;  
class Program
{
    static void Main()   
    {  //Multiplicaciones sobre el porcentaje de cada descuento 
        Console.WriteLine("Sueldo neto para empleados de una empresa de calzado");
        double sueldoBase = ObtenerSueldoBase();
        double renta = CalcularDescuento(sueldoBase, 0.10);
        double afp = CalcularDescuento(sueldoBase, 0.07);
        double seguroSocial = CalcularDescuento(sueldoBase, 0.05);
        MostrarResumen(sueldoBase, renta, afp, seguroSocial); 
        //tipo double por los decimales
    }
    static double ObtenerSueldoBase()
    {
        double sueldoBase;
        do
        {       //comparacion si el sueldo es igual o menor a lo solicitado
            Console.Write("Ingrese el sueldo base del empleado (mínimo 3300): ");
            //comparacion de valor
        } while (!double.TryParse(Console.ReadLine(), out sueldoBase) || sueldoBase < 3300);
        return sueldoBase;
    }
    static double CalcularDescuento(double sueldoBase, double porcentaje)
    {
        return sueldoBase * porcentaje;   //si todo bien, retorna una respuesta
    }
    static void MostrarResumen(double sueldoBase, double renta, double afp, double seguroSocial)
    {
        double sueldoNeto = sueldoBase - renta - afp - seguroSocial;  //resultado de sueldo neto 
        //impresion de cada resultado 
        Console.WriteLine("\nDESCEUNTOS Y SUELDO NETO");
        Console.WriteLine($"Sueldo Base: Q.{sueldoBase}"); 
        Console.WriteLine($"Descuento Renta (10%): Q.{renta}");
        Console.WriteLine($"Descuento Beneficio AFP (7%): Q.{afp}");
        Console.WriteLine($"Descuento Seguro Social (5%): Q.{seguroSocial}");
        Console.WriteLine($"Sueldo Neto a Pagar: Q.{sueldoNeto}");
    } 
}

//EJERCICIO 3
//Permita digitar una cantidad en kilometros pero que convierta a metros , yardas y varas 
//1mt ? 1.09361  yardas 1mt=1.1963 varas 