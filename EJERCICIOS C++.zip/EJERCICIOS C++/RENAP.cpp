#include <iostream>
#include <vector>
#include <string>
using namespace std;



// Estructura para almacenar los datos de una persona
struct Persona {
    string nombre;
    string vecindad;
    int dia;
    int mes;
    int anio;
};

// Funci�n para calcular la edad
int calcularEdad(int anioNacimiento) {
    int anioActual = 2024; // Asumimos el a�o actual como 2024
    return anioActual - anioNacimiento;
}

// Funci�n para buscar personas por nombre
void buscarPorNombre(const vector<Persona>& personas, const string& nombreBuscado) {
    for (const auto& Persona : personas) {
        if (Persona.nombre == nombreBuscado) {
            cout << "Persona encontrada:" << endl;
            cout << "Nombre: " << Persona.nombre << endl;
            cout << "Lugar de nacimiento: " << Persona.vecindad << endl;
            cout << "Fecha de nacimiento: " << Persona.dia << "/" << Persona.mes << "/" << Persona.anio << endl;
            cout << endl;
            return;
        }
    }
    cout << "No se encontr� ninguna persona con ese nombre." << endl;
}

int main() {
    int numPersonas;
    cout << "Ingrese el numero de personas en la fila: ";
    cin >> numPersonas;

    // Vector para almacenar los datos de las personas
    vector<Persona> personas(numPersonas);

    // Ingresar datos de cada persona
    for (int i = 0; i < numPersonas; ++i) {
        cout << "Persona " << i + 1 << ":" << endl;
        cout << "Nombre: ";
        cin >> personas[i].nombre;
        cout << "Lugar de nacimiento: ";
        cin >> personas[i].vecindad;
        cout << "Fecha de nacimiento (dd mm aaaa): ";
        cin >> personas[i].dia >> personas[i].mes >> personas[i].anio;
    }

    // Mostrar datos y calcular si es mayor de edad
    cout << "\nDatos ingresados:" << endl;
    for (int i = 0; i < numPersonas; ++i) {
        cout << "Nombre: " << personas[i].nombre << endl;
        cout << "Lugar de nacimiento: " << personas[i].vecindad << endl;
        cout << "Fecha de nacimiento: " << personas[i].dia << "/" << personas[i].mes << "/" << personas[i].anio << endl;

        int edad = calcularEdad(personas[i].anio);
        cout << "Edad: " << edad << " a�os";
        if (edad >= 18) {
            cout << " (mayor de edad)" << endl;
        } else {
            cout << " (menor de edad)" << endl;
        }
        cout << endl;
    }
    
    // B�squeda por nombre
    cout << "\nBuscar persona por nombre:" << endl;
    string nombreBuscado;
    cout << "Ingrese el nombre a buscar: ";
    cin >> nombreBuscado;
    buscarPorNombre(personas, nombreBuscado);

    return 0;
}




