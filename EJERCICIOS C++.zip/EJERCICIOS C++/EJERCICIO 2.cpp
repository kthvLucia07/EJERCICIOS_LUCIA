#include <iostream>
#include <vector>

using namespace std;

int main() {
      int numeros[5]  = {10, 20, 30, 40, 50};
int suma =0; 
int  promedio;
double porcentaje; 

for(int i=0; i<5; i++){
	suma += numeros[i];
}

promedio=suma/5;
porcentaje= suma*0.25; 

    // Imprimir resultados
    cout << "Suma total: " << suma << endl;
    cout << "Promedio general: " << promedio << endl;
    cout << "Promedio del 25% de los valores: " <<  porcentaje<<"%"  << endl;

    return 0;
}
