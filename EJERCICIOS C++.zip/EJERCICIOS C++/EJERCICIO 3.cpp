#include <iostream>
#include <algorithm> 

using namespace std; 

void Cambio(int &valor) {
    if (valor % 2 == 0) {
        valor += 1;    // para cada  numero par 
    } else {
        valor -= 2;  //sino para cada impar 
    }

    valor = max(valor, 0); //caso contrario se coloca cero si es numero negativo
}

int main() {
    const int tam = 5;
    int vector[tam];

    
    cout << "Ingrese los valores :" << endl;
    for (int i = 0; i < tam; ++i) {
        cout << "Ingrese el valor-: posicion " << i + 1 << ": ";  //digitar valores
        cin >> vector[i];
    }

    for_each(vector, vector + tam, Cambio); //funcion "para cada" y se llaman a las funciones 
    for (int i = 0; i < tam; ++i) {
        cout << "Dato en la posicion " << i + 1 << ": " << vector[i] - (vector[i] % 2) << endl;
        cout << "Cambio de valor  " << i + 1 << ": " << vector[i] <<endl<<endl<<endl;
    }

    return 0;
}
